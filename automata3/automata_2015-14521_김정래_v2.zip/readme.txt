#실행방법 : 
#g++ automata3.cpp
#./a.out TM.txt string.txt output.txt

#만약 디버깅모드(매스탭마다 테입 상황과 테입에서 현재 가리키고 있는 칸을 알려주는 모드) 하시고 싶으시면 주석처리를 빼시면 됩니다.

환경은 Xcode c++ 11 on Mac 입니다.